import csv

file_name = 'employees.csv'

new_employees = [
    {
        'Имя': 'Александр',
        'Должность': 'Продавец',
        'Зарплата': 15000
    },
    {
        'Имя': 'Алексей',
        'Должность': 'Менеджер',
        'Зарплата': 25000
    },
    {
        'Имя': 'Томм',
        'Должность': 'Админ',
        'Зарплата': 23000
    }
]

with open(file_name, 'a',newline='',encoding='utf-8') as file:
    writer = csv.writer(file)

    for item in new_employees:
        writer.writerow([item['Имя'], item['Должность'], item['Зарплата']])

print(f'Данные условия записаны в файл: {file_name}')