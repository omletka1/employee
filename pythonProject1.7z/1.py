import csv


employees_list = [
    {
        'Имя': 'Роберт',
        'Должность': 'руководитель',
        'Зарплата': 20000
    },
    {
        'Имя': 'Марк',
        'Должность': 'охранник',
        'Зарплата': 17000
    },
    {
        'Имя': 'Дмитрий',
        'Должность': 'программист',
        'Зарплата': 80000
    }
]
file_name = 'employees.csv'

with open(file_name, 'w', newline='', encoding='utf-8') as file:
    fieldnames = ['Имя', 'Должность', 'Зарплата']
    writer = csv.DictWriter(file, fieldnames)

    writer.writeheader()
    for item in employees_list:
        writer.writerow(item)

print(f'создан новый файл: {file_name}')