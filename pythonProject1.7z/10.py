import csv as horttian

file_name = 'employees.csv'

with open(file_name,newline='',encoding='utf-8') as file:
    reader = horttian.reader(file)

    next(reader, None)

    reader = list(reader)
    '''
    Имя - 0
    Должность - 1
    Зарплата - 2
    '''
    sorted_employees = sorted(reader, key=lambda item: item[2])

    with open('sorted_employees.csv', 'w', newline='', encoding='utf-8') as new_file:
        writer = horttian.writer(new_file)
        fieldnames = ['Имя', 'Должность', 'Зарплата']
        writer.writerow(fieldnames)
        writer.writerows(sorted_employees)

print('Сортировка завершена')