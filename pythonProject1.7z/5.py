import csv

file_name = 'employees.csv'

name = input('Введите имя: ')
age = input("Введите должность: ")
amount = input("Введите зарплату: ")

with open(file_name, 'a',newline='',encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow([name, age, amount])

print(f'Сотрудник {name} успешно добавлен в файл: {file_name}')