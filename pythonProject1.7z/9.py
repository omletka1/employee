import csv as omletka

new_file_name = input('Введите имя нового файла: ')

with open(new_file_name,'w', newline='',encoding='utf-8') as file:
    students_data = [
        {'Имя': 'Алексей', 'Должность': 'Рабочий', 'Зарплата': 2000},
        {'Имя': 'Марина', 'Должность': 'Консультант', 'Зарплата': 40000},
    ]

    writer = omletka.writer(file)
    for item in students_data:
        writer.writerow([item['Имя'], item['Должность'], item['Зарплата']])

with open(new_file_name,newline='',encoding='utf-8') as file:
    reader = omletka.reader(file)

    next(reader, None)

    for item in reader:
        print(item[0], item[1], item[2])